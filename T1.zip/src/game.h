#pragma once

#include "system.h"

void setup();
void loop();